package raf.aleksabuncic.types;

/**
 * Node visibility.
 */
public enum NodeVisibility {
    PUBLIC,
    PRIVATE
}
