package raf.aleksabuncic.types;

public record BootstrapConfig(String ip, int port) {}