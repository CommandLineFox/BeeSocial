package raf.aleksabuncic.types;

public enum NodeVisibility {
    PUBLIC,
    PRIVATE
}
